  <body class="be-splash-screen">
    <div class="be-wrapper be-error be-error-404">
      <div class="be-content">
        <div class="main-content container-fluid">
          <div class="error-container">
            <div class="error-number">404</div>
            <div class="error-description">The page you are looking for might have been removed or underconstruction.</div>
            <div class="error-goback-text">Would you like to go home?</div>
            <div class="error-goback-button"><a href="<?=base_url(); ?>" class="btn btn-xl btn-primary">Let's go home</a></div>
            <div class="footer">&copy; 2019  EARIST CIT COOP</div>
          </div>
        </div>
      </div>
    </div>
