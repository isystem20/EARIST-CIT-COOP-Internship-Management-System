<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require_once dirname(__FILE__) . '/pusher/vendor/autoload.php';

class PusherClass extends ComposerAutoloaderInitbb8adfce5e5df4493d244bf53cf9768f
{
    function __construct()
    {
        // parent::__construct();
    }
}