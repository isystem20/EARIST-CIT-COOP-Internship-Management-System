
  <body>
    <div class="be-wrapper be-collapsible-sidebar be-collapsible-sidebar-collapsed">
